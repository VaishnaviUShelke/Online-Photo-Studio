<?php include("navbar.php")?>
        <div class="container-fluid   p-md-5" id="about" style="background-color: rgb(224, 255, 228);">
            <h1 class="text-center">About Us</h1>
            <hr>
            <div class="row">
                <?php 
                    $select="select * from tblaboutus id ";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <div class="col-md-4 col-sm-12">
                        <img src="admin/<?php echo $row['companylogo']; ?>" alt="logo" class="img-fluid m-2" style="height:100%;width:100%">
                    </div>
                    <div class="col-md-8 col-sm-12">
                        <h3 class="text-center"><?php echo $row['companyname']; ?></h3>
                        <p style="text-indent: 50px; text-align:justify;"><?php echo $row['companydesc']; ?></p>
                        
                    </div>
                    <?php } ?>
            </div>
        </div>
        <hr>
        <div class="container-fluid p-5 bg-light">
            <h1 class="text-center">Our Expert Team</h1>
            <hr>
            <div class="row">
            <?php 
                    $select="select * from tblaboutus2 id ";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                <div class="col-md-4 col-sm-12">
                    <div class="card">
                        <img src="admin/<?php echo $row['empimg']; ?>" class="card-img-top rounded" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['empname']; ?></h5>
                            <p style="text-indent: 50px; text-align:justify;"><?php echo $row['empdesc']; ?></p>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
<?php include("footer.php")?>