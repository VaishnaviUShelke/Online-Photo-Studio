<?php include_once('adminnavbar.php')?>
  
      <?php include_once('../connection.php'); ?>
      <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div class="row">
          <h1 class="h2">Contact us Data</h1>
          <hr>
            <div class="col-12">
                <table class="table table-borderd">
                    <thead>
                    <tr>
                        <th>Action</th>
                        <th>Sr.No.</th>
                        <th>Name</th>
                        <th>Email_ID</th>
                        <th>Mobile No.</th>
                        <th>Event name</th>
                        <th>Message</th>
                        <th>Date & Time</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sqlquery="select * from tblcontactus";
                        $res=mysqli_query($conn,$sqlquery);
                        $i=1;
                        while($row=mysqli_fetch_assoc($res)){ ?>
                            <tr>
                                <td>
                                  <form action="" method="post">
                                    <input type="hidden" name="id_<?php echo $row['id'];?>" id="id_<?php echo $row['id'];?>" value="<?php echo $row['id'];?>">
                                    <button type="submit" name="delete_<?php echo $row['id'];?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button>
                                  </form>
                                  <?php
                                    if(isset($_POST['delete_'.$row['id']])){
                                      $id=$_POST['id_'.$row['id']];
                                      $delsql="delete from tblcontactus where id='$id'";
                                      $sss=mysqli_query($conn,$delsql);
                                      if($sss){
                                        echo "<script> alert('Contact us data deleted successfully.')</script>";
                                        echo "<script> window.location='admincontact.php'</script>";
                                      }
                                    }
                                  ?>
                                </td>
                                <td><?php echo $i++; ?></td>
                                <td><?php echo $row['fname']; ?></td>
                                <td><?php echo $row['femail']; ?></td>
                                <td><?php echo $row['fphone']; ?></td>
                                <td><?php echo $row['fevent']; ?></td>
                                <td><?php echo $row['fmessage']; ?></td>
                                <td><?php echo $row['inserttime']; ?></td>
                            </tr>
                    <?php  }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
      </main>
<?php include_once('adminfooter.php')?>