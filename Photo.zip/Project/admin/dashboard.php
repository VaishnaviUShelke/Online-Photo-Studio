<?php include_once('adminnavbar.php') ?>
<style>
        
        .card{
            transition: transform .2s; /* Animation */
        }
        .card:hover{
            transform: scale(1.1);
        }
</style>
      <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div class="container-fluid">
          <br>
          <h1 class="h2">Dashboard</h1>
          <hr>
            <div class="row">
              <div class="col-xl-4 col-md-6 mb-4">
                  <a href="adminabout.php" class="text-decoration-none">
                      <div class="card border-left-primary shadow h-100 py-2">
                          <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                  <div class="col mr-2">
                                      <div class="h5  font-weight-bold text-uppercase mb-1" style="color:#4B0505;">
                                          About Us
                                      </div>
                                      <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                          View Details
                                      </div>
                                  </div>
                                  <div class="col-auto">
                                      <i class="fa fa-user fa-2x text-gray-300" style="color:#4B0505;"></i>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </a>
              </div>
              <div class="col-xl-4 col-md-6 mb-4">
                  <a href="adminteam.php" class="text-decoration-none">
                      <div class="card border-left-primary shadow h-100 py-2">
                          <div class="card-body">
                              <div class="row no-gutters align-items-center">
                                  <div class="col mr-2">
                                      <div class="h5  font-weight-bold text-uppercase mb-1" style="color:#4B0505;">
                                          Team Data
                                      </div>
                                      <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                          View Details
                                      </div>
                                  </div>
                                  <div class="col-auto">
                                      <i class="fa fa-user fa-2x text-gray-300" style="color:#4B0505;"></i>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </a>
              </div>
              <div class="col-xl-4 col-md-6 mb-4">
                    <a href="admingallery.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5  font-weight-bold  text-uppercase mb-1" style="color:#4B0505;">
                                        Gallery
                                        </div>
                                        <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                            View Details
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fa fa-photo fa-2x text-gray-300" style="color:#4B0505;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-md-6 mb-4">
                    <a href="adminservice.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5  font-weight-bold text-uppercase mb-1" style="color:#4B0505;">
                                        Service
                                        </div>
                                        <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                            View Details
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fa fa-cog fa-2x text-gray-300" style="color:#4B0505;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-md-6 mb-4">
                    <a href="adminblogs.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5  font-weight-bold  text-uppercase mb-1" style="color:#4B0505;">
                                            Blog
                                        </div>
                                        <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                            View Details
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fa fa-list fa-2x text-gray-300" style="color:#4B0505;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-md-6 mb-4">
                    <a href="admincontact.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5  font-weight-bold text-uppercase mb-1" style="color:#4B0505;">
                                        Contact Us
                                        </div>
                                        <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                            View Details
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fa fa-phone fa-2x text-gray-300" style="color:#4B0505;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-md-6 mb-4">
                    <a href="index.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5  font-weight-bold  text-uppercase mb-1" style="color:#4B0505;">
                                        Logout
                                        </div>
                                        <div class="text-xs mb-0 font-weight-bold text-gray-800" style="color:#4B0505;">
                                            View Details
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fa fa-sign-out fa-2x text-gray-300" style="color:#4B0505;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
      </main>
<?php include_once('adminfooter.php') ?>