<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Admin Login</title>
    <link rel="shortcut icon" href="img/shri.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>

<body style="background-image:url(https://img.freepik.com/premium-photo/sunset-with-mountains-clouds-background_859451-4145.jpg);background-repeat:no-repeat;background-size:cover;">
 <?php 
        include_once('../connection.php');
        if(isset($_POST['login'])){
            $username=$_POST['username'];
            $password=$_POST['password'];
            $sqlquery="select * from tbladmin where username='".$username."' and password='".$password."'";
            $res=mysqli_query($conn,$sqlquery);
            if(mysqli_num_rows($res)>0){
                $row=mysqli_fetch_assoc($res);
                $_SESSION['id']=$row['id'];
                $_SESSION['username']=$row['username'];
                $otp=rand(111111,999999);
                $update="update tbladmin set otp='".$otp."' where id='".$row['id']."'";
                mysqli_query($conn,$update);
                $_SESSION['otp']=$otp;
                echo "<script> alert('Login Successfully.');</script>";
                ?>
    <script>
    $(document).ready(function() {
        $('#exampleModal').modal('show');
    });
    </script>
    <?php
            }else{
                echo "<script> alert('Your Username & Password Not Match. Please try Again.');</script>";
                echo "<script> window.location='index.php';</script>";
            }
        }
?>
     <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" style="height: 50px; width:300px;border-radius:15px;">
        <div class="modal-content shadow" style="border-radius:15px;">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">OTP Verification</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
                <form action="otpchk.php" method="post">
                    <div class="row">
                        <h6 class="text-center">OTP send on +9170xxxx6449</h6>
                        <h6 class="text-center">OTP : <?php echo $_SESSION['otp']; ?></h6>
                        <div class="col-12 p-5 ">
                            <div class="row mb-3">
                                <div class="col-12">
                                    <div class="input-group">
                                        <label for="" class="input-group-text"><i class="fa fa-key"></i></label>
                                        <input type="Password" name="otp" class="form-control" id="otp" placeholder="Enter OTP">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-12">
                                    <div class="form-check">
                                        <input type="radio" class="form-check-input" id="check11" name="option11" value="something" onclick="showpassword()">
                                        <label class="form-check-label" for="check11">Show OTP</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-12 text-center">
                                    <button type="submit" class="btn btn-primary" name="checkotp">Verify</button>
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <div class="container shadow" style="height:350px;width:450px;border-radius:15px;margin-top: 100px;">
        <div class="row">
            <h1 class="text-center text-white p-2">Admin Login</h1>
            <hr>
            
            <div class="col-12">
                <form action="" method="post">
                    
                        <div class="input-group mb-3 mt-3">
                            <span for="text" class="input-group-text bg-black text-white slash1" id="username"><i class="fa fa-user"></i></span>
                            <input type="text" class="form-control" id="username" placeholder="Enter username" name="username">
                            
                        </div>
                        <div class="input-group mb-3 mt-3">
                            <span for="text" class="input-group-text bg-black text-white slash1" ><i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
                            
                        </div>
                        <div class="row mb-3">
                            <div class="col-12">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="pass" name="pass" onclick="myFunction()">
                                    <label class="form-check-label text-white" for="pass">Show Password</label>
                                </div>
                            </div>
                        </div>
                        <center>
                        <button type="submit" class="btn btn-primary mb-3 " name="login">Login</button>
                        <button type="reset" class="btn btn-warning mb-3 " >Cancel</button>
                        </center>
                </form>
                <br>
            </div>
      </div>
    </div>
    <script>
        function myFunction() {
            //alert('hello');
          var x = document.getElementById("password");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        function showotp() {
            //alert('hello');
          var x = document.getElementById("otp");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        </script>    
</body>
</html>