<?php include("navbar.php")?>
    <div class="container-fluid  p-5" id="blogs" style="background-color: azure;">
                <h1 class="text-center">Blogs</h1>
                <hr>

                <div class="row">
                    <?php 
                    $select="select * from tblblogs order by id desc";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="card">
                            <img src="admin/<?php echo $row['blogimg']; ?>" class="card-img-top " alt="... " height="250">
                            <div class="card-body ">
                                <h5 class="card-title "><?php echo $row['blogname']; ?></h5>
                                <p class="card-text ">
                                    <?php echo $row['blogdesc']; ?>
                                </p>
                                <center>
                                    <div id="demo" class="collapse">
                                    <?php echo $row['blogdesc2']; ?>
                                    </div>
                                    <button type="button" class="btn btn-dark"data-bs-toggle="collapse" data-bs-target="#demo<?php echo $row['id']; ?>">Read More...</button>
                                </center>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
    </div>
<?php include("footer.php")?>