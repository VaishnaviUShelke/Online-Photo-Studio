<?php
    error_reporting(1);
    $pagename=basename($_SERVER['PHP_SELF']);
    if($pagename=='index.php'){
        session_start();
        session_destroy();
    }
    session_start();
    date_default_timezone_set("Asia/Kolkata");
    $servername="localhost";
    $username="root";
    $password="";
    $conn=mysqli_connect($servername,$username,$password);
    if(!$conn){
        die('Connection is not successfull, please try again.');
    }else{
        //echo "Connection is successfull.";
    }
    mysqli_select_db($conn,"photographydb");
?>