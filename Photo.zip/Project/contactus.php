<?php include("navbar.php")?>
        <div class="container-fluid p-5" style="background-color: rgb(238, 234, 248);">
            <h1 class="text-center">Contact Us</h1>
            <hr>
            <div class="row">
                <div class="col-md-6 col-sm-12 text-center">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1934492.9226788038!2d72.32146412499999!3d18.7398421!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2afadfac6d4e9%3A0xa2e1fe0c3542b279!2sShree%20Photo%20Studio!5e0!3m2!1sen!2sin!4v1703324393959!5m2!1sen!2sin" width="100%" height="100%" style="border:5px solid black;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="col-md-6 col-sm-12 p-5">
                    <h2 class="text-center">Inquiry</h2>
                    <hr>
                    <form action="save.php" method="post" onsubmit="return validation()">
                        <div class="row mb-3">
                            <div class="col-4">
                                <h6><label for="">Name</label></h6>
                            </div>
                            <div class="col-8"><input type="text" name="fname" id="fname" class="form-control" placeholder="Enter Name" autofocus></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">
                                <h6><label for="">Email</label></h6>
                            </div>
                            <div class="col-8"><input type="email" name="femail" id="femail" class="form-control" placeholder="Enter Email"></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">
                                <h6><label for="">Mobile</label></h6>
                            </div>
                            <div class="col-8"><input type="tel" name="fphone" id="fphone" class="form-control" placeholder="Enter Mobile No"></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">
                                <h6><label for="">Event</label></h6>
                            </div>
                            <div class="col-8"><input type="text" name="fevent" id="fevent" class="form-control" placeholder="Enter Event"></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-4">
                                <h6><label for="">Message</label></h6>
                            </div>
                            <div class="col-8">
                                <textarea name="fmessage" id="fmessage" rows="4" placeholder="Enter Message" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-success btn-lg" name="datasave">Save</button>
                                <button type="reset" class="btn btn-warning btn-lg" name="datareset">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
        function validation() {
            var fname = document.getElementById('fname').value;
            var femail = document.getElementById('femail').value;
            var fmobile = document.getElementById('fphone').value;
            var fsubject = document.getElementById('fevent').value;
            var fmessage = document.getElementById('fmessage').value;

            if (fname.trim() == '') {
                alert('Please Enter Your Name');
                document.getElementById('fname').value = "";
                document.getElementById('fname').focus();
                return false;
            }
            if (femail.trim() == '') {
                alert('Please Enter Your Email');
                document.getElementById('femail').value = "";
                document.getElementById('femail').focus();
                return false;
            }
            if (fmobile.trim() == '') {
                alert('Please Enter Your Mobile No');
                document.getElementById('fphone').value = "";
                document.getElementById('fphone').focus();
                return false;
            }
            if (fsubject.trim() == '') {
                alert('Please Enter Your Event');
                document.getElementById('fevent').value = "";
                document.getElementById('fevent').focus();
                return false;
            }
            if (fmessage.trim() == '') {
                alert('Please Enter Your Message');
                document.getElementById('fmessage').value = "";
                document.getElementById('fmessage').focus();
                return false;
            }
            return true;
        }
    </script>

 <?php include("footer.php")?>