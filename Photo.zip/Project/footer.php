<footer>
            <div class="container-fluid bg-dark p-5">
                <div class="row">
                    <div class="col-md-4 col-sm-12 text-center">
                        <h5 class="text-white">Shree Photo Studio</h5>
                        <img src="img/shri.jpg" alt="" class="img-fluid" style="width: 250px;height: 250px;">
                        <p class="text-white-50">We are provide all types of photoshoot.</p>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <h5 class="text-white">Menus</h5>
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php"><i class="fa fa-home"></i>  Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="services.php"><i class="fa fa-cog"></i> Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="aboutus.php"><i class="fa fa-user"></i> About Us</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href=gallery.php"><i class="fa fa-image"></i> Gallery</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href=blogs.php"><i class="fa fa-list"></i> Blogs</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact Us</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/index.php"><i class="fa fa-lock"></i> Admin Login</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <h5 class="text-white">Contact Details</h5>
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" href="tel:+917028926449"><i class="fa fa-phone"></i>  +91 7028926449</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="malito: vaishnavi7777pranav@gmail.com"><i class="fa fa-envelope"></i>  vaishnavi7777pranav@gmail.com</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#"><i class="fa fa-map-marker"></i>  Address : Shop No 1, Dhore Wada, Vadgaon, Maharashtra 412106</a>
                            </li>
                        </ul>
                        <ul class="d-inline-flex" style="list-style-type: none;">
                            <li><a class="nav-link" href="#"><i class="fa fa-whatsapp fa-2x"></i></a></li>
                            <li><a class="nav-link" href="#"><i class="fa fa-facebook fa-2x"></i></a></li>
                            <li><a class="nav-link" href="#"><i class="fa fa-twitter fa-2x"></i></a></li>
                            <li><a class="nav-link" href="#"><i class="fa fa-youtube fa-2x"></i></a></li>
                        </ul>
                        <ul class="d-inline-flex" style="list-style-type: none;">
                            <li><a class="nav-link" href="#"><i class="fa fa-instagram fa-2x"></i></a></li>
                            <li><a class="nav-link" href="#"><i class="fa fa-linkedin fa-2x"></i></a></li>
                            <li><a class="nav-link" href="admin/index.php"><i class="fa fa-user fa-2x"></i></a></li>
                        </ul>
                    </div>
                </div>
                <hr class="bg-white">
                <p class="text-center text-white mt-3"><i class="fa fa-globe"></i> Develop By Vaishnavi Shelke @2023-2024.</p>
            </div>
</footer>
</body>
</html>