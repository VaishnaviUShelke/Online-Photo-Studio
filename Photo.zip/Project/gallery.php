<?php include("navbar.php")?>
        <div class="container-fluid p-5" id="images" style="background-color: rgb(228, 226, 254);">
            <h1 class="text-center">Our Images</h1>
            <hr>
            <div class="row">
                <?php 
                    $select="select * from tblgallery id where category='image'";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                ?>
                <div class="col-md-4 col-sm-6 mb-3">
                    <img src="admin/<?php echo $row['logo']; ?>" class="img-fluid img-thumbnail w-100 h-100" alt="...">
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="container-fluid p-5" id="video" style="background-color: rgb(250, 220, 252);">
            <h1 class="text-center">Our Videos</h1>
            <hr>
            <div class="row">
                <?php 
                    $select="select * from tblgallery id where category='video'";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                ?>
                <div class="col-md-4 col-sm-6 mb-3">
                    <iframe width="100%" height="100%" src="<?php echo $row['documentry']; ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
                <?php } ?>
                
            </div>
        </div>
        <div class="container-fluid p-5" id="documentry" style="background-color: rgb(251, 235, 235);">
            <h1 class="text-center">Our Documentry</h1>
            <hr>
            <div class="row">
                <div class="col-md-4 col-sm-6 mb-3">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/ikuzAyLYgIQ?si=hzc10def4gc-DHRX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
                <div class="col-md-4 col-sm-6 mb-3">
                    <img src="img/we card.jpg" class="img-fluid img-thumbnail" alt="...">
                </div>
                <div class="col-md-4 col-sm-6 mb-3">
                    <img src="img/card.jpg" class="img-fluid img-thumbnail w-100" alt="..." style="height: 365px;">
                </div>
                <div class="col-md-4 col-sm-6 mb-3">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/xOkzr7sOGDo?si=sJYJoJ8q5zZBTFR4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
                <div class="col-md-4 col-sm-6 mb-3">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/MSQP3BqmENk?si=09NuxNgYrbOmaEGp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
                <div class="col-md-4 col-sm-6 mb-3">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/VR5x0WHrUZI?si=JnTtnz7COQ3Sm0Vb" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
        </div>
<?php include("footer.php")?>