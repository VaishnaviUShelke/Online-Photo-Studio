<?php include("navbar.php")?>
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 4"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="5" aria-label="Slide 4"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/photo1.jpg" class="d-block w-100 h-50" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Baby Photoshoot</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/photo02.jpg" class="d-block w-100 h-50" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Engagement Photoshoot</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/photo3.jpg" class="d-block w-100 h-50" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Post-wedding Photoshoot</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/photo4.jpg" class="d-block w-100 h-50" alt="..........">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Pre-wedding Photoshoot</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/photo5.jpg" class="d-block w-100 h-50" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Nature Photoshoot</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/photo77.jpg" class="d-block w-100 h-50" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Photoshoot</h5>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
        </div>

        <hr>
            <div class="container-fluid  p-md-5" id="about" style="background-color: rgb(224, 255, 228);">
                <h1 class="text-center">About Us</h1>
                <hr>
                <div class="row">
                    <?php 
                        $select="select * from tblaboutus id ";
                        $res=mysqli_query($conn,$select);
                        while($row=mysqli_fetch_assoc($res)){
                        ?>
                        <div class="col-md-4 col-sm-12">
                            <img src="admin/<?php echo $row['companylogo']; ?>" alt="logo" class="img-fluid m-2" style="height:100%;width:100%">
                        </div>
                        <div class="col-md-8 col-sm-12">
                            <h3 class="text-center"><?php echo $row['companyname']; ?></h3>
                            <p style="text-indent: 50px; text-align:justify;"><?php echo $row['companydesc']; ?></p>
                            
                        </div>
                        <?php } ?>
                </div>
            </div>

        <hr>

        <div class="container-fluid  p-5" id="services" style="background-color: rgb(244, 238, 205);">
            <h1 class="text-center">Services</h1>
            <hr>
            <div class="row">
                <?php 
                    $select="select * from  tblservices id";
                    $res=mysqli_query($conn,$select);
                    while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <div class="col-md-4 col-sm-6 p-2">
                        <div class="card">
                            <img src="admin/<?php echo $row['serviceimg']; ?>"  class="card-img-top " alt="... " height="250">
                            <div class="card-body ">
                                <h5 class="card-title "><?php echo $row['servicename']; ?></h5>
                                
                                <center>
                                    <a href="https://api.whatsapp.com/send?phone=917028926449&amp;text=Hi, I am contacting you through your website" class="btn btn-primary "><i class="fa fa-whatsapp"></i> Book now...</a>
                                </center>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
            </div>
        </div>

        <hr>
        <div class="container-fluid  p-5" id="blogs" style="background-color:azure;">
            <h1 class="text-center">Blogs</h1>
            <hr>

            <div class="row">
                <?php 
                $select="select * from tblblogs order by id desc";
                $res=mysqli_query($conn,$select);
                while($row=mysqli_fetch_assoc($res)){
                ?>
                <div class="col-md-4 col-sm-6">
                    <div class="card">
                        <img src="admin/<?php echo $row['blogimg']; ?>" class="card-img-top " alt="... " height="250">
                        <div class="card-body ">
                            <h5 class="card-title "><?php echo $row['blogname']; ?></h5>
                            <p class="card-text ">
                                <?php echo $row['blogdesc']; ?>
                            </p>
                            <center>
                                <a href="blogs.php" class="btn btn-dark">Read Article</a>
                            </center>

                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
<?php include("footer.php")?>