<?php include("navbar.php")?>

<style>
    h2{
        font-size:50px;
        font-family: 'EB Garamond', serif;
        text-align:center;
       
    }
    h4{
        font-style:italic; 
        text-align:center;
    }
    
</style>

<div class="container-fluid  p-5" id="packages" style="background-color: rgb(244, 238, 205);">
                <h1 class="text-center">Packages</h1>
                <hr>
     <div class="row">
        <div class="col-md-3 col-sm-6 mt-5">
            <div class="row mx-3">
                <h2>Family Photoshoot</h2>
                <ul style="list-style-type:none;">
                    <li><h4>RS.2500</h4></li>
                    <hr>
                    <li>1 Hour Unlimited Shots</li>
                    <hr>
                    <li>All Images Inclusive In High-Resolution</li>
                    <hr>
                    <li>Best 40 Edited</li>
                    <hr>
                    <li>Seasonal Theme</li>
                </ul>
            </div>
        </div>

        <div class="col-md-3 col-sm-6 mt-5">
            <div class="row mx-3">
            <h2>Wedding Photoshoot</h2>
                <ul style="list-style-type:none;">
                    <li><h4>RS.5000</h4></li>
                    <hr>
                    <li>2 Hour Unlimited Shots</li>
                    <hr>
                    <li>All Images Inclusive In High-Resolution</li>
                    <hr>
                    <li>Best 40 Edited</li>
                    <hr>
                    <li>Seasonal Theme</li>
                </ul>
            </div>
        </div>

        <div class="col-md-3 col-sm-6 mt-5">
            <div class="row mx-3">
            <h2>Maternity Photoshoot</h2>
                <ul style="list-style-type:none;">
                    <li><h4>RS.5500</h4></li>
                    <hr>
                    <li>3 Hour Unlimited Shots</li>
                    <hr>
                    <li>All Images Inclusive In High-Resolution</li>
                    <hr>
                    <li>Best 40 Edited</li>
                    <hr>
                    <li>Seasonal Theme</li>
                </ul>
            </div>
        </div>

        <div class="col-md-3 col-sm-6 mt-5">
            <div class="row mx-3">
            <h2>Bussiness Photoshoot</h2>
                <ul style="list-style-type:none;">
                <li><h4>RS.3500</h4></li>
                    <hr>
                    <li>3 Hour Unlimited Shots</li>
                    <hr>
                    <li>All Images Inclusive In High-Resolution</li>
                    <hr>
                    <li>Best 40 Edited</li>
                    <hr>
                    <li>All bussiness Theme</li>
            </div>
        </div>
     </div>           
</div>
<?php include("footer.php")?>