<?php
    include_once("connection.php");
    if(isset($_POST['datasave'])){
        $fname=$_POST['fname'];
        $femail=$_POST['femail'];
        $fphone=$_POST['fphone'];
        $fevent=$_POST['fevent'];
        $fmessage=$_POST['fmessage'];
        echo "<br>fname= ".$fname;
        echo "<br>femail= ".$femail;
        echo "<br>fphone= ".$fphone;
        echo "<br>fevent= ".$fevent;
        echo "<br>fmessage= ".$fmessage;
        $inserttime=date('Y-m-d h:i:s a');
        echo "<br>sqlquery = ".$sqlquery="insert into tblcontactus(fname,femail,fphone,fevent,fmessage,inserttime) values('".$fname."','".$femail."','".$fphone."','".$fevent."','".$fmessage."','".$inserttime."')";
        mysqli_query($conn,$sqlquery);
        header('location:contactus.php');
    }
?>