<?php include("navbar.php")?>
    <div class="container-fluid  p-5" id="services" style="background-color: rgb(244, 238, 205);">
                <h1 class="text-center">Services</h1>
                <hr>
                <div class="row">
                    <?php 
                        $select="select * from  tblservices id";
                        $res=mysqli_query($conn,$select);
                        while($row=mysqli_fetch_assoc($res)){
                        ?>
                        <div class="col-md-4 col-sm-6 p-2">
                            <div class="card">
                                <img src="admin/<?php echo $row['serviceimg']; ?>"  class="card-img-top " alt="... " height="250">
                                <div class="card-body ">
                                    <h5 class="card-title "><?php echo $row['servicename']; ?></h5>
                                    <p class="card-text ">
                                        <?php echo $row['servicedesc']; ?>                                
                                    </p>
                                    <center>
                                        <a href="https://api.whatsapp.com/send?phone=917028926449&amp;text=Hi, I am contacting you through your website" class="btn btn-primary "><i class="fa fa-whatsapp"></i> Book now...</a>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                </div>
    </div>
<?php include("footer.php")?>